Run the program separately. Put the data set in the same directory as the program.

I have two mrjob files. One is class notes and the other is another approach.



